from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import (
    TipoLojaViewSet, PlanoAssinaturaViewSet, LojaViewSet,
    FinanceiroLojaViewSet, PagamentoLojaViewSet, UsuarioSistemaViewSet,
    recuperar_senha_loja
)

router = DefaultRouter()
router.register(r'tipos-loja', TipoLojaViewSet, basename='tipo-loja')
router.register(r'planos', PlanoAssinaturaViewSet, basename='plano')
router.register(r'lojas', LojaViewSet, basename='loja')
router.register(r'financeiro', FinanceiroLojaViewSet, basename='financeiro')
router.register(r'pagamentos', PagamentoLojaViewSet, basename='pagamento')
router.register(r'usuarios', UsuarioSistemaViewSet, basename='usuario-sistema')

# IMPORTANTE: Rotas públicas devem vir ANTES do include do router
urlpatterns = [
    path('lojas/recuperar_senha/', recuperar_senha_loja, name='loja-recuperar-senha'),
    path('', include(router.urls)),
]
